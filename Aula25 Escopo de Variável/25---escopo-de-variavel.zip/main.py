'''
def cadastrar_usuario(nome, idade, cidade="Não informado"):
    print(f"Cadastro: {nome}, {idade}, {cidade}")

cadastrar_usuario(idade = 30, cidade = "SJS", nome = "Carlos")
'''
def mostrar_nome():
    nome = "Joao"
    return nome
# print(nome) - não funciona
print(mostrar_nome())

numero = 10 # Variável global
def calculo():
    global numero
    numero = 20
calculo()
print(numero)